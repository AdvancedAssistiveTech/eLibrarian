package eLibrarian;

import java.io.*;
import java.util.*;

public class Installers {
	Util utility = new Util();
	
	String uinput = null;
	
	Formatter fwrite = null;
	
	Scanner uin = new Scanner(System.in);
	Scanner reader = null;
	
	char id;
	String username, password;
	
	public void C() {
		System.out.println("Beginning installation...\n\n");
		try {
			new File("C:/eLib").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory C:/eLib. Please try again later");
			utility.exit();
		}
		System.out.println("Directory C:/eLib created successfully");
		try {
			new File("C:/eLib/main").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory C:/eLib/main. Please try again later");
			utility.exit();
		}
		System.out.println("Directory C:/eLib/main created successfully");
		try {
			new File("C:/eLib/data").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory C:/eLib/data. Please try again later");
			utility.exit();
		}
		System.out.println("Directory C:/eLib/data created successfully");
		try {
			new File("C:/eLib/main/ic.cf").createNewFile();
		}
		catch(Exception e) {
			System.out.print("Error creating installation verification file. Please try again later");
			utility.exit();
		}
		System.out.println("Installation verification file created successfully");
		System.out.println("\nInstallation on C: drive successful");
	}
	public void D() {
		System.out.println("Beginning installation...\n\n");
		try {
			new File("D:/eLib").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory D:/eLib. Please try again later");
			utility.exit();
		}
		System.out.println("Directory D:/eLib created successfully");
		try {
			new File("D:/eLib/main").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory D:/eLib/main. Please try again later");
			utility.exit();
		}
		System.out.println("Directory D:/eLib/main created successfully");
		try {
			new File("D:/eLib/data").mkdir();
		}
		catch(Exception e) {
			System.out.println("Error creating directory D:/eLib/data. Please try again later");
			utility.exit();
		}
		System.out.println("Directory D:/eLib/data created successfully");
		try {
			new File("D:/eLib/ic.cf").createNewFile();
		}
		catch(Exception e) {
			System.out.print("Error creating installation verification file. Please try again later");
			utility.exit();
		}
		System.out.println("Installation verification file created successfully");
		System.out.println("\nInstallation on D: drive successful");
	}
	public void userData(){
		id = utility.dircheck(id, "C:/eLib/main/ic.cf", "D:/eLib/main/ic.cf");
		if(id == 'a') {
			try {
				fwrite = new Formatter("C:/eLib/main/lidat.cf"); //logindata.criticalfile
			}
			catch(FileNotFoundException a) {
				System.out.println("Error code a");
			}
			catch(SecurityException b) {
				utility.Criticalexit("Write permission denied");
			}
		}
		else if(id == 'b') {
			try {
				fwrite = new Formatter("D:/eLib/main/lidat.cf"); //logindata.criticalfile
			}
			catch(Exception e) {
				utility.Criticalexit(Character.toString(id));
			}
		}
		else {
			utility.Criticalexit("Bad installation. Please reinstall");
		}
		System.out.print("Please confirm your user details. Note that these will be required upon login" + "\n\n" + "Username: ");
		username = uin.next();
		System.out.print("Password: ");
		password = uin.next();
		fwrite.format("%s %n%s", username, password);
		fwrite.close();
	}
	public void signin() {
		id = utility.dircheck(id, "C:/eLib/main/ic.cf", "D:/eLib/main/ic.cf");
		if(id == 'a') {
			try {
				reader = new Scanner(new File("C:/eLib/main/lidat.cf"));
			}
			catch(Exception e) {}
		}
		else if(id == 'b') {
			try {
				reader = new Scanner(new File("D:/eLib/main/lidat.cf"));
			}
			catch(Exception e) {}
		}
		else {
			utility.Criticalexit("Bad installation. Please reinstall");
		}
		while(reader.hasNext()) {
			username = reader.next();
			password = reader.next();  
		}
		while(true) {
			System.out.print("Username: ");
			uinput = uin.nextLine();
			if(uinput.equals(username)) {
				break;
			}
			System.out.println("Incorrect. Try again");
		}
		while(true) {
			System.out.print("Password: ");
			uinput = uin.nextLine();
			if(uinput.equals(password)) {
				break;
			}
			System.out.println("Incorrect. Try again");
		}
	}
	public Boolean instval(Boolean x) { //installation validator
		id = 'z';
		if(utility.dircheck(id, "C:/eLib/main/ic.cf", "D:/eLib/main/ic.cf") != 'z') {
			x = true;
		}
		else {
			x = false;
		}
		return x;
	}
}
