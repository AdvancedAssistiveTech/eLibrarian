package eLibrarian;

import java.util.*;
import java.io.*;

public class Kevin {
 static Formatter fwrite = new Formatter();
 static Scanner fread;
 static Util util = new Util();
 static char id = 'y';
 static int jane = 0;
 static int dex = 0;
 static int bi1,bi2, bi3;
 static String bs1, bs2, bs3;
 
 public static void greet() {
	 System.out.println("\r\n" + 
	 		"       _     _ _                    _             \r\n" + 
	 		"   ___| |   (_) |__  _ __ __ _ _ __(_) __ _ _ __  \r\n" + 
	 		"  / _ \\ |   | | '_ \\| '__/ _` | '__| |/ _` | '_ \\ \r\n" + 
	 		" |  __/ |___| | |_) | | | (_| | |  | | (_| | | | |\r\n" + 
	 		"  \\___|_____|_|_.__/|_|  \\__,_|_|  |_|\\__,_|_| |_|\r\n" + 
	 		"                                                  \r\n" + 
	 		"");
 }
 
 public static String[][] booktable(String[][] petro){
	id = util.dircheck(id, "C:/eLib/main/ic.cf", "D:/elib/main/ic.cf");
	if(id == 'a') {
		try {
			fread = new Scanner(new File("C:/elib/data/num.data"));
		}
		catch(Exception e) {}
	}
	else if(id == 'b') {
		try {
			fread = new Scanner(new File("D:/elib/data/num.data"));
		}
		catch(Exception e) {}
	}
	dex = fread.nextInt();
	petro = new String[7][dex];
	if(id == 'a') {
		try {
			fread = new Scanner(new File("C:/elib/data/bs.data"));
		}
		catch(Exception e) {}
	}
	else if(id == 'b') {
		try {
			fread = new Scanner(new File("D:/elib/data/bs.data"));
		}
		catch(Exception e) {}
	}
	for(int x = 0; fread.hasNext(); x++) {
		petro[0][x] = fread.next();
		petro[1][x] = fread.next();
		petro[2][x] = fread.next();
		}
	return petro; 
 }
 public static int numread(int x){
	 id = util.dircheck(id, "C:/eLib/main/ic.cf", "D:/elib/main/ic.cf");
	if(id == 'a') {
		try {
			fread = new Scanner(new File("C:/elib/data/num.data"));
		}
		catch(Exception e) {}
	}
	else if(id == 'b') {
		try {
			fread = new Scanner(new File("D:/elib/data/num.data"));
		}
		catch(Exception e) {}
	}
	if(fread.hasNext()) {
		x = fread.nextInt();
	}
	return x;
 }
 public static void main(String args[]) {
	 Installers install = new Installers();
	 
	 String[][] precore = null; //preexisting core information
	 String[][] newcore; //new core information
	 String[] presign; //preexisting sign-outers
	 String[] newsign; //new sign-outers
	 Scanner sc = new Scanner(System.in);
	 String uinput;
	 Boolean valid = false; //Installation validity checker
	 Boolean firstrun = true;
	 
	 if(!install.instval(valid)) {
		 System.out.print("Installation not validated. Install now? (y,n)");
		 uinput = sc.next();
		 if(uinput.startsWith("y") || uinput.startsWith("Y")) {
			 System.out.print("Please specify installation drive (c, d)");
			 uinput = sc.next();
			 if(uinput.startsWith("c") || uinput.startsWith("C")) {
				 install.C();
			 }
			 if(uinput.startsWith("d") || uinput.startsWith("D")) {
				 install.D();
			 }
		 }
		 else {
			 util.exit();
		 } 
	 }
	 System.out.println("Installation validated");
	 id = util.dircheck(id, "C:/eLib/main/lidat.cf", "D:/eLib/main/lidat.cf");
	 if(id == 'z') {
		 install.userData();
	 }
	 else {
		 firstrun = false;
	 }
	 System.out.println("User data validated");
	 if(!firstrun) {
		 install.signin();
	 } 
	 greet();
	 while(true) {
		 System.out.println("1. Register new books\n" +
		 					"2. Search books\n" +
		 					"3. Sign books out\n" +
				 			"4. Exit\n");
		 uinput = sc.next();
	if(uinput.equals("1") || uinput.startsWith("R") || uinput.startsWith("r")) {
		 jane = numread(jane);
		 precore = booktable(precore);
		 System.out.println("Register how many books? ");
		 dex = sc.nextInt();
		 newcore = new String[7][dex];
		 for(int x = 0; x < dex; x++) {
			 String uinput2;
			 while(true) {
				 System.out.print("Name of book: ");
				 uinput = sc.next();
				 System.out.print("Confirm name of book is " + uinput + " (y, n): ");
				 uinput2 = sc.next();
				 if(uinput2.startsWith("y") || uinput2.startsWith("Y")) {
					 newcore[0][x] = uinput;
					 System.out.println("Genre of book: ");
					 uinput = sc.next();
					 System.out.println("Confirm genre of "  + newcore[0][x] + " is " +  uinput + " (y, n):");
					 uinput2 = sc.next();
					 if(uinput2.startsWith("y") || uinput2.startsWith("Y")) {
						 newcore[1][x] = uinput;
						 newcore[2][x] = "false";
						 break;
					 }
				 }
			 }
		 }
		 id = util.dircheck(id, "C:/eLib/main/ic.cf", "D:/eLib/main/ic.cf");
		 if(id == 'a') {
			 try {
				 fwrite = new Formatter("C:/elib/data/bs.data"); //Bookstore
			 }
			 catch(Exception e) {
			 }
		 }
		 else if(id == 'b') {
			 try {
				 fwrite = new Formatter("D:/elib/data/bs.data"); 
			 }
			 catch(Exception e) {
			 }
		 }
		 for(int x = 0; x < (jane * 2) - 1; x++) { // preexisting books
			 fwrite.format("%s%n", precore[0][x]); // saves name of book
			 fwrite.format("%s%n", precore[1][x]); // saves genre of book
			 fwrite.format("%s%n", precore[2][x]); // whether the book has been signed out or not
		 }
		 for(int x = 0; x < dex; x++) { 		   // new books
			 fwrite.format("%s%n", newcore[0][x]); // saves name of book
			 fwrite.format("%s%n", newcore[1][x]); // saves genre of book
			 fwrite.format("%s%n", newcore[2][x]); // whether the book has been signed out or not
		 }
		 fwrite.close();
		 if(id == 'a') {
			 try {
				 fwrite = new Formatter("C:/elib/data/num.data"); //numbers.data
			 }
			 catch(Exception e) {
			 }
		 }
		 else if(id == 'b') {
			 try {
				 fwrite = new Formatter("D:/elib/data/num.data"); 
			 }
			 catch(Exception e) {
			 }
		 }
		 dex += jane;
		fwrite.format("%s", dex);
	}
	if(uinput.equals("2") || uinput.startsWith("S") || uinput.startsWith("s")) {
		 precore = booktable(precore);
		 System.out.println("Name of book: ");
		 uinput = sc.next();
		 jane = 0;
		 
		 id = util.dircheck(id, "C:/eLib/main/ic.cf", "D:/eLib/main/ic.cf");
		 if(id == 'a') {
			 try {
				 fread = new Scanner(new File("C:/elib/data/num.data")); //Numbers
			 }
			 catch(Exception e) {
			 }
		 }
		 else if(id == 'b') {
			 try {
				 fread = new Scanner(new File("D:/elib/data/num.data")); 
			 }
			 catch(Exception e) {
			 }
		 }
		 
		 for(int x = 0, y = fread.nextInt(); x < y; x++) {
			 if(precore[0][x].contains(uinput)) { //If search is found
				 System.out.println("Search found: " + precore[0][x]);
				 jane++;
			 }
		 }
		 
		 if(jane == 0) {
			 System.out.println("Search returned negative result");
		 }
		 else {
			 System.out.println("Search returned " + jane + " result/s");
		 }
	}
	else if(uinput.equals("3") || uinput.startsWith("b") || uinput.startsWith("B")) {
		jane = 0;
		while(true) {
			System.out.println("Welcome to the eLibrarian sign-out utility");
			while(true) {
				System.out.print("Name of borrower: ");
				bs1 = sc.next();
				System.out.println("Confirm borrowers name is " + bs1 + " (y, n)");
				uinput = sc.next();
				if(uinput.equals("y") || uinput.equals("Y")) {
					jane++;
					break;
				}
			}
			precore = booktable(precore);
			while(true) {
				System.out.print("Name of book: ");
				bs2 = sc.next();
				System.out.println("Confirm book name is " + bs2 + " (y, n)");
				uinput = sc.next();
				if(uinput.equals("y") || uinput.equals("Y")) {
					break;
				}
			}
			 id = util.dircheck(id, "C:/eLib/main/ic.cf", "D:/eLib/main/ic.cf");
			 if(id == 'a') {
				 try {
					 fread = new Scanner(new File("C:/elib/data/num.data")); //Numbers
				 }
				 catch(Exception e) {
				 }
			 }
			 else if(id == 'b') {
				 try {
					 fread = new Scanner(new File("D:/elib/data/num.data")); 
				 }
				 catch(Exception e) {
				 }
			 }
			 int z = 0;
			 for(int x = 0, y = fread.nextInt(); x < y; x++) {
				 if(precore[0][x].contains(bs2)) { //If search is found
					 z++;
				 }
			 }
			 if(z > 0) {
				 String[] result = new String[z];
				 System.out.println("Search found: ");
				 for(int x = 0, y = fread.nextInt(); x < y; x++) {
					 if(precore[0][x].contains(bs2)) { //If search is found
						 result[x] = precore[0][x];
						 System.out.println(x + ". " + result[x]);   
					 }
				 }
				 while(true) {
					 System.out.print("Please select result: "); 
					 bi1 = sc.nextInt();
					 if(bi1 > z) {
						 System.out.println("Invalid input. Try again");
					 }
					 else {
						 System.out.print("Confirm selection of result " + bi1 + " (y, n)");
						 uinput = sc.next();
						 if(uinput.startsWith("y") || uinput.startsWith("Y")) { 
							 bi1 -= 1;
							 break;
						 }
					 }
				 }
				 for(int x = 0; x < z; x++) {
					 if(precore[0][x] == result[bi1]) {
						 precore[2][x] = "true";
					 }
				 }
				 break;
			 }
		}
		newsign = new String[jane];
	}
	else if(uinput.equals("4") || uinput.startsWith("E") || uinput.startsWith("e")) {
		System.out.println("\nExiting in five seconds...");
		try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
		}
		System.out.print("Terminated");
		break;
	}
	}
	sc.close();
	fwrite.close(); 
 }
}