package eLibrarian;

import java.util.*;
import java.io.*;

public class Kevin {
 static Formatter fwrite = new Formatter();
 static Scanner fread = null;
 static Util util = new Util();
 static char id = 'y';
 static int jane = 0;
 static int dex = 0;
 
 public static void greet() {
	 System.out.println("\r\n" + 
	 		"       _     _ _                    _             \r\n" + 
	 		"   ___| |   (_) |__  _ __ __ _ _ __(_) __ _ _ __  \r\n" + 
	 		"  / _ \\ |   | | '_ \\| '__/ _` | '__| |/ _` | '_ \\ \r\n" + 
	 		" |  __/ |___| | |_) | | | (_| | |  | | (_| | | | |\r\n" + 
	 		"  \\___|_____|_|_.__/|_|  \\__,_|_|  |_|\\__,_|_| |_|\r\n" + 
	 		"                                                  \r\n" + 
	 		"");
 }
 
 public static String[][] booktable(String[][] petro){
	id = util.dircheck(id, "C:/eLib/main/ic.cf", "D:/elib/main/ic.cf");
	if(id == 'a') {
		try {
			fread = new Scanner(new File("C:/elib/data/num.data"));
		}
		catch(Exception e) {}
	}
	else if(id == 'b') {
		try {
			fread = new Scanner(new File("D:/elib/data/num.data"));
		}
		catch(Exception e) {}
	}
	dex = fread.nextInt();
	petro = new String[7][dex];
	if(id == 'a') {
		try {
			fread = new Scanner(new File("C:/elib/data/bs.data"));
		}
		catch(Exception e) {}
	}
	else if(id == 'b') {
		try {
			fread = new Scanner(new File("D:/elib/data/bs.data"));
		}
		catch(Exception e) {}
	}
	for(int x = 0; fread.hasNext(); x++) {
		petro[0][x] = fread.next();
		petro[1][x] = fread.next();
		}
	return petro; 
 }
 public static void main(String args[]) {
	 Installers install = new Installers();
	 
	 String[][] precore = null; //preexisting core information
	 String[][] newcore; //new core information
	 Scanner sc = new Scanner(System.in);
	 String uinput;
	 Boolean valid = false; //Installation validity checker
	 Boolean firstrun = true;
	 
	 if(!install.instval(valid)) {
		 System.out.print("Installation not validated. Install now? (y,n)");
		 uinput = sc.next();
		 if(uinput.startsWith("y") || uinput.startsWith("Y")) {
			 System.out.print("Please specify installation drive (c, d)");
			 uinput = sc.next();
			 if(uinput.startsWith("c") || uinput.startsWith("C")) {
				 install.C();
			 }
			 if(uinput.startsWith("d") || uinput.startsWith("D")) {
				 install.D();
			 }
		 }
		 else {
			 util.exit();
		 } 
	 }
	 System.out.println("Installation validated");
	 id = util.dircheck(id, "C:/eLib/main/lidat.cf", "D:/eLib/main/lidat.cf");
	 if(id == 'z') {
		 install.userData();
	 }
	 else {
		 firstrun = false;
	 }
	 System.out.println("User data validated");
	 if(!firstrun) {
		 install.signin();
	 } 
	 greet();
	 System.out.println("1. Register new books\n" +
			 			"2. Search books\n");
	 uinput = sc.next();
	 if(uinput.equals("1") || uinput.startsWith("R") || uinput.startsWith("r")) {
		 System.out.println("Register how many books? ");
		 dex = sc.nextInt();
		 newcore = new String[7][dex];
		 for(int x = 0, y = Integer.parseInt(uinput); x < y; x++) {
			 String uinput2;
			 while(true) {
				 System.out.print("Name of book: ");
				 uinput = sc.next();
				 System.out.print("Confirm name of book is " + uinput + " (y, n): ");
				 uinput2 = sc.next();
				 if(uinput2.startsWith("y") || uinput2.startsWith("Y")) {
					 newcore[0][x] = uinput;
					 System.out.println("Genre of book: ");
					 uinput = sc.next();
					 System.out.println("Confirm genre of "  + newcore[0][x] + " is " +  uinput + " (y, n):");
					 uinput2 = sc.next();
					 if(uinput2.startsWith("y") || uinput2.startsWith("Y")) {
						 newcore[1][x] = uinput;
						 break;
					 }
				 }
			 }
		 }
		 id = util.dircheck(id, "C:/eLib/main/ic.cf", "D:/eLib/main/ic.cf");
		 if(id == 'a') {
			 try {
				 fwrite = new Formatter("C:/elib/data/bs.data"); //Bookstore
			 }
			 catch(Exception e) {
			 }
		 }
		 else if(id == 'b') {
			 try {
				 fwrite = new Formatter("D:/elib/data/bs.data"); 
			 }
			 catch(Exception e) {
			 }
		 }
		 for(int x = 0; x < dex; x++) {
			 fwrite.format("%s%n", newcore[0][x]); // saves name of book
			 fwrite.format("%s%n", newcore[1][x]); // saves genre of book
		 }
		 fwrite.close();
		 if(id == 'a') {
			 try {
				 fwrite = new Formatter("C:/elib/data/num.data"); //numbers.data
			 }
			 catch(Exception e) {
			 }
		 }
		 else if(id == 'b') {
			 try {
				 fwrite = new Formatter("D:/elib/data/num.data"); 
			 }
			 catch(Exception e) {
			 }
		 }
		fwrite.format("%s", dex);
	 }
	 if(uinput.equals("2") || uinput.startsWith("S") || uinput.startsWith("s")) {
		 precore = booktable(precore);
		 System.out.println("Name of book: ");
		 uinput = sc.next();
		 jane = 0;
		 for(int x = 0; x < precore.length; x++) {
			 if(precore[0][x].contains(uinput)) {
				 System.out.println(precore[0][x]);
				 jane++;
			 }
		 }
		 if(jane == 0) {
			 System.out.println("Search returned negative result");
		 }
	 }
	 sc.close();
	 fwrite.close();
 }
}

