package eLibrarian;

import java.util.Scanner;

public class Kevin {
 public static void greet() {
	 System.out.println("\r\n" + 
	 		"       _     _ _                    _             \r\n" + 
	 		"   ___| |   (_) |__  _ __ __ _ _ __(_) __ _ _ __  \r\n" + 
	 		"  / _ \\ |   | | '_ \\| '__/ _` | '__| |/ _` | '_ \\ \r\n" + 
	 		" |  __/ |___| | |_) | | | (_| | |  | | (_| | | | |\r\n" + 
	 		"  \\___|_____|_|_.__/|_|  \\__,_|_|  |_|\\__,_|_| |_|\r\n" + 
	 		"                                                  \r\n" + 
	 		"");
 }
 public static void main(String args[]) {
	 Installers install = new Installers();
	 Util util = new Util();
	 
	 Scanner sc = new Scanner(System.in);
	 String uinput;
	 Boolean valid = false; //Installation validity checker
	 Boolean firstrun = true;
	 
	 char id = 'y';
	 
	 if(!install.instval(valid)) {
		 System.out.print("Installation not validated. Install now? (y,n)");
		 uinput = sc.next();
		 if(uinput.startsWith("y") || uinput.startsWith("Y")) {
			 System.out.print("Please specify installation drive (c, d)");
			 uinput = sc.next();
			 if(uinput.startsWith("c") || uinput.startsWith("C")) {
				 install.C();
			 }
			 if(uinput.startsWith("d") || uinput.startsWith("D")) {
				 install.D();
			 }
		 }
		 else {
			 util.exit();
		 } 
	 }
	 System.out.println("Installation validated");
	 id = util.dircheck(id, "C:/eLib/main/lidat.cf", "D:/eLib/main/lidat.cf");
	 if(id == 'z') {
		 install.userData();
	 }
	 else {
		 firstrun = false;
	 }
	 System.out.println("User data validated");
	 if(!firstrun) {
		 install.signin();
	 } 
	 greet();
	 System.out.println("1. Register new books");
	 sc.close();
 }
}

