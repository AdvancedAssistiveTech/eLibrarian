package eLibrarianJ11;

import java.io.File;

public class UtilitiesJ11 {
	File f;
	public void exit() {
		System.out.println("\nExiting in five seconds...");
		try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
		}
		System.out.print("Terminated");
		System.exit(0);
	}
	public void Criticalexit(String errmess) {
		System.out.println("\n\n" + errmess + ". Exiting...");
		System.exit(1);
	}
	public char dircheck(char y, String directorya, String directoryb) { //directory determiner / installation verifier
		f = new File(directorya);
		if(f.exists()) {
			y = 'a';
		}
		else {
			f = new File(directoryb);
			if(f.exists()) {
				y = 'b';
			}
			else {
				y = 'z'; //Error
			}
		}
		return y;
	}
}
